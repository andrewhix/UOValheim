# Ultima Valheim Combat Module

## Overview
The Combat Module implements Ultima Online-style combat mechanics optimized for large-scale PvP in Valheim. It features weapon quality tiers, material-based progression, skill-based damage scaling, and extensive performance optimizations for 10+ player battles.

## Features

### Weapon System
- **11 Material Tiers**: Iron, Shadow, Gold, Agapite, Verite, Snow, Ice, Bloodrock, Valorite, Blackrock
- **5 Magic Quality Tiers**: Ruin (+3), Might (+6), Force (+9), Power (+12), Vanquishing (+15)
- **Dynamic Generation**: Magic qualities are generated on-the-fly, not stored as separate prefabs
- **150+ Weapons**: Currently starting with Longswords (11 material variants)

### Damage System
- **Custom Formula**: `(Base + Quality) × Material × (1 + Skill/100)`
- **Quality Bonuses**: Flat damage additions (+3/+6/+9/+12/+15)
- **Material Multipliers**: 1.0x (Iron) to 4.0x (Blackrock)
- **Skill Scaling**: Linear 0-100, doubles damage at max skill
- **Damage Caching**: Player damage stats cached and invalidated on equipment change

### Performance Optimizations
- **Damage Batching**: Syncs damage every 100ms instead of per-hit (90% traffic reduction)
- **Spatial Culling**: Only syncs combat to players within 50m (80% traffic reduction)
- **ZPackage Pooling**: Reuses network objects to prevent GC spikes
- **Calculation Caching**: Caches damage calculations, invalidates on equipment/skill change
- **Event Throttling**: Limits non-critical event broadcasts to prevent overload

### Target Performance
- **Frame Time**: <2ms per hit
- **Network Traffic**: <10 KB/s per player
- **GC Collections**: Zero during combat
- **Player Capacity**: 10-20 simultaneous PvP without lag

## Installation

1. Copy `UltimaValheimCombat` folder to your solution directory
2. Open `UOV.sln` and add the Combat project (or use the updated `UOV_Updated.sln`)
3. Build the project
4. Copy `Ultima_Valheim_Weapons_Balance.csv` to one of these locations:
   - `BepInEx/plugins/UltimaValheim/Ultima_Valheim_Weapons_Balance.csv`
   - `BepInEx/config/UltimaValheim/Ultima_Valheim_Weapons_Balance.csv`

## Dependencies

### Required
- **UltimaValheimCore** (v1.0.0+) - Hard dependency
- **BepInEx** (5.4.2202)
- **Jotunn** (2.20.2)
- **HarmonyX** (2.13.0)

### Optional
- **UltimaValheimSkills** - Soft dependency for skill-based damage scaling

## Configuration

Config file: `BepInEx/config/com.valheim.ultima.combat.cfg`

### General Settings
- `EnableCombatSystem` - Enable/disable combat module (default: true)

### Performance Settings
- `EnableDamageBatching` - Batch damage updates (default: true, recommended for PvP)
- `DamageSyncInterval` - Sync interval in seconds (default: 0.1)
- `CombatSyncRadius` - Sync radius in meters (default: 50)

### Balance Settings
- `EnableSkillScaling` - Scale damage by weapon skills (default: true)
- `SkillDamageMultiplier` - Skill effectiveness multiplier (default: 1.0)

### Debug Settings
- `EnableCombatLogging` - Detailed combat logs (default: false, performance impact)

## Architecture

```
UltimaValheimCombat/
├── CombatModule.cs              # Main module (ICoreModule)
├── CombatPlugin.cs              # BepInEx plugin entry point
├── Data/
│   ├── WeaponData.cs            # Weapon stats structures
│   └── WeaponDatabase.cs        # CSV loader and lookup
├── Systems/
│   ├── DamageCalculator.cs     # Damage formulas with caching
│   ├── CombatSyncManager.cs    # Network batching and spatial culling
│   └── WeaponManager.cs        # Weapon registration and generation
└── Patches/
    ├── Character_Damage.cs     # Intercepts damage calculations
    ├── Humanoid_EquipItem.cs   # Cache invalidation on equip
    └── Player_Update.cs        # Ticks sync manager
```

## Weapon Creation Flow

### Base Weapons (Craftable)
1. WeaponDatabase loads CSV data
2. WeaponManager creates prefabs for each material
3. Adds crafting recipes
4. Registers with Jotunn

### Magic Quality Weapons (Drop Only)
1. Loot Module determines drop: "Agapite Longsword + Power"
2. Calls: `WeaponManager.CreateWeaponWithQuality()`
3. WeaponManager:
   - Clones base prefab
   - Adds "of Power" to name
   - Stores quality tier in custom data
   - Returns enhanced weapon
4. DamageCalculator reads quality and applies +12 damage bonus

## Damage Calculation Flow

1. Player attacks target
2. `Character_Damage` Harmony patch intercepts
3. DamageCalculator checks cache:
   - **Cache hit**: Use cached damage
   - **Cache miss**: Calculate and cache
4. Apply formula: `(Base + Quality) × Material × (1 + Skill/100)`
5. Queue damage for batched sync
6. Every 100ms, sync batched damage with spatial culling

## Extending the System

### Adding New Weapon Types
1. Add weapon data to CSV
2. WeaponManager will automatically register all material variants
3. Configure weapon-specific stats (speed, stagger, etc.)

### Custom Damage Types
Modify `DamageCalculator.CalculateDamage()` to add:
- Elemental damage
- Critical hits
- Armor penetration
- Status effects

## Testing

### Solo Testing
- Use vanilla weapons as placeholders
- Test damage calculations
- Verify caching and cache invalidation

### Multiplayer Testing
- 2-4 players: Test basic sync
- 10+ players: Stress test performance
- Monitor with Unity Profiler (F8)
- Check network traffic with Wireshark

## Performance Monitoring

Get statistics in-game:
```csharp
var calculator = combatModule.GetDamageCalculator();
var stats = calculator.GetCacheStats();
// Returns: (cachedPlayers, totalEntries)

var syncManager = combatModule.GetSyncManager();
var syncStats = syncManager.GetSyncStats();
// Returns: (pendingDamageCount, lastSyncTime)
```

## Known Issues

1. **Skills Integration**: GetSkillBonus() returns 0 until Skills module API is finalized
2. **Weapon Name Parsing**: ExtractWeaponName() needs refinement based on final naming convention
3. **PvE Balance**: Current focus is PvP; PvE damage may need separate balancing

## Roadmap

### Phase 1 (Current)
- [x] Core damage system
- [x] Network optimization
- [x] Longsword implementation

### Phase 2
- [ ] Add remaining weapon types (Katana, Broadsword, Mace, etc.)
- [ ] Skills module integration
- [ ] Fine-tune PvP balance

### Phase 3
- [ ] Advanced combat mechanics (blocking, parrying, combos)
- [ ] Weapon special abilities
- [ ] Combat statistics tracking

### Phase 4
- [ ] Tournament/arena system
- [ ] Combat analytics dashboard
- [ ] Advanced anti-cheat measures

## Support

For issues, feature requests, or questions:
- Check the main project documentation
- Review the COMBAT_MODULE_ARCHITECTURE_SUMMARY.md
- Consult COMBAT_MODULE_SPECIFICATION.md for detailed technical info

## License

Part of the Ultima Valheim project.
