using System;
using System.Collections.Generic;
using System.IO;
using System.Globalization;
using UltimaValheim.Core;

namespace UltimaValheim.Combat.Data
{
    /// <summary>
    /// Loads and manages weapon data from CSV file.
    /// Provides fast lookup of weapon stats by name and material.
    /// </summary>
    public class WeaponDatabase
    {
        private readonly Dictionary<string, WeaponData> _weaponData = new Dictionary<string, WeaponData>();
        private bool _isLoaded = false;

        /// <summary>
        /// Load weapon data from embedded CSV resource or external file.
        /// </summary>
        public bool LoadFromCSV(string csvPath)
        {
            try
            {
                if (!File.Exists(csvPath))
                {
                    CoreAPI.Log.LogError($"[WeaponDatabase] CSV file not found: {csvPath}");
                    return false;
                }

                string[] lines = File.ReadAllLines(csvPath);
                if (lines.Length < 2)
                {
                    CoreAPI.Log.LogError("[WeaponDatabase] CSV file is empty or has no data rows");
                    return false;
                }

                // Skip header row
                for (int i = 1; i < lines.Length; i++)
                {
                    string line = lines[i];
                    if (string.IsNullOrWhiteSpace(line))
                        continue;

                    try
                    {
                        WeaponData weapon = ParseWeaponLine(line);
                        string key = GetWeaponKey(weapon.WeaponName, weapon.Material);
                        _weaponData[key] = weapon;
                    }
                    catch (Exception ex)
                    {
                        CoreAPI.Log.LogWarning($"[WeaponDatabase] Failed to parse line {i}: {ex.Message}");
                    }
                }

                _isLoaded = true;
                CoreAPI.Log.LogInfo($"[WeaponDatabase] Loaded {_weaponData.Count} weapon entries from CSV");
                return true;
            }
            catch (Exception ex)
            {
                CoreAPI.Log.LogError($"[WeaponDatabase] Failed to load CSV: {ex}");
                return false;
            }
        }

        /// <summary>
        /// Get weapon data by weapon name and material.
        /// Returns true if found, false otherwise.
        /// </summary>
        public bool TryGetWeaponData(string weaponName, string material, out WeaponData data)
        {
            string key = GetWeaponKey(weaponName, material);
            return _weaponData.TryGetValue(key, out data);
        }

        /// <summary>
        /// Get weapon data by ItemDrop.ItemData (extracts name and material from item).
        /// </summary>
        public bool TryGetWeaponData(ItemDrop.ItemData item, out WeaponData data)
        {
            if (item == null)
            {
                data = default;
                return false;
            }

            // Extract weapon name and material from item
            string weaponName = ExtractWeaponName(item);
            string material = ExtractMaterial(item);

            return TryGetWeaponData(weaponName, material, out data);
        }

        /// <summary>
        /// Get all weapons of a specific type (e.g., all "Longsword" variants)
        /// </summary>
        public List<WeaponData> GetAllVariants(string weaponName)
        {
            var variants = new List<WeaponData>();
            foreach (var weapon in _weaponData.Values)
            {
                if (weapon.WeaponName.Equals(weaponName, StringComparison.OrdinalIgnoreCase))
                {
                    variants.Add(weapon);
                }
            }
            return variants;
        }

        /// <summary>
        /// Get all weapon names (unique weapon types)
        /// </summary>
        public HashSet<string> GetAllWeaponNames()
        {
            var names = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            foreach (var weapon in _weaponData.Values)
            {
                names.Add(weapon.WeaponName);
            }
            return names;
        }

        public bool IsLoaded => _isLoaded;
        public int WeaponCount => _weaponData.Count;

        #region Private Helper Methods

        private string GetWeaponKey(string weaponName, string material)
        {
            // Normalize to lowercase for case-insensitive lookup
            return $"{weaponName}_{material}".ToLower();
        }

        private WeaponData ParseWeaponLine(string line)
        {
            // Parse CSV line (handle quoted fields that may contain commas)
            string[] fields = ParseCSVLine(line);

            if (fields.Length < 21)
            {
                throw new FormatException($"Expected 21 fields, got {fields.Length}");
            }

            return new WeaponData(
                weaponName: fields[0].Trim(),
                skillType: fields[1].Trim(),
                damageType: fields[2].Trim(),
                material: fields[3].Trim(),
                baseDamage: ParseFloat(fields[4]),
                ruinDamage: ParseFloat(fields[6]),
                ruinDamageAt100: ParseFloat(fields[7]),
                mightDamage: ParseFloat(fields[8]),
                mightDamageAt100: ParseFloat(fields[9]),
                forceDamage: ParseFloat(fields[10]),
                forceDamageAt100: ParseFloat(fields[11]),
                powerDamage: ParseFloat(fields[12]),
                powerDamageAt100: ParseFloat(fields[13]),
                vanquishingDamage: ParseFloat(fields[14]),
                vanquishingDamageAt100: ParseFloat(fields[15]),
                skillMultAt100: ParseFloat(fields[16]),
                staggerVsPlayers: fields[19].Trim(),
                speedNote: fields[20].Trim()
            );
        }

        private string[] ParseCSVLine(string line)
        {
            var fields = new List<string>();
            bool inQuotes = false;
            var currentField = new System.Text.StringBuilder();

            for (int i = 0; i < line.Length; i++)
            {
                char c = line[i];

                if (c == '"')
                {
                    inQuotes = !inQuotes;
                }
                else if (c == ',' && !inQuotes)
                {
                    fields.Add(currentField.ToString());
                    currentField.Clear();
                }
                else
                {
                    currentField.Append(c);
                }
            }

            // Add the last field
            fields.Add(currentField.ToString());

            return fields.ToArray();
        }

        private float ParseFloat(string value)
        {
            if (string.IsNullOrWhiteSpace(value))
                return 0f;

            if (float.TryParse(value, NumberStyles.Float, CultureInfo.InvariantCulture, out float result))
                return result;

            return 0f;
        }

        /// <summary>
        /// Extract weapon base name from ItemDrop.ItemData.
        /// Handles vanilla weapons and custom naming conventions.
        /// </summary>
        private string ExtractWeaponName(ItemDrop.ItemData item)
        {
            // For now, use the item's shared name
            // This will need to be refined based on your naming convention
            // Example: "IronLongsword" -> "Longsword", "AgapiteLongsword" -> "Longsword"
            string itemName = item.m_shared?.m_name ?? "";
            
            // Try to extract weapon type (remove material prefix)
            // This is a placeholder - adjust based on your actual item naming
            string[] materials = { "Iron", "Shadow", "Gold", "Agapite", "Verite", "Snow", "Ice", "Bloodrock", "Valorite", "Blackrock" };
            foreach (var material in materials)
            {
                if (itemName.StartsWith(material, StringComparison.OrdinalIgnoreCase))
                {
                    return itemName.Substring(material.Length);
                }
            }

            return itemName;
        }

        /// <summary>
        /// Extract material from ItemDrop.ItemData.
        /// </summary>
        private string ExtractMaterial(ItemDrop.ItemData item)
        {
            // For now, try to extract from item name
            // This will need to be refined based on your naming convention
            string itemName = item.m_shared?.m_name ?? "";
            
            string[] materials = { "Blackrock", "Valorite", "Bloodrock", "Ice", "Snow", "Verite", "Agapite", "Gold", "Shadow", "Iron" };
            foreach (var material in materials)
            {
                if (itemName.Contains(material, StringComparison.OrdinalIgnoreCase))
                {
                    return material.ToLower();
                }
            }

            // Default to iron if no material found
            return "iron";
        }

        #endregion
    }
}
