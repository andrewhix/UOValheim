using System;
using System.IO;
using BepInEx.Configuration;
using HarmonyLib;
using UltimaValheim.Core;
using UltimaValheim.Combat.Data;
using UltimaValheim.Combat.Systems;

namespace UltimaValheim.Combat
{
    /// <summary>
    /// Combat module for Ultima Valheim.
    /// Handles weapon system, damage calculations, and network optimization for PvP.
    /// </summary>
    [ModuleDependency("UltimaValheim.Core", MinVersion = "1.0.0")]
    [ModuleDependency("UltimaValheim.Skills", Soft = true)]
    public class CombatModule : ICoreModule
    {
        public string ModuleID => "UltimaValheim.Combat";
        public System.Version ModuleVersion => new System.Version(1, 0, 0);

        // Configuration
        private ConfigEntry<bool> _enableCombatSystem;
        private ConfigEntry<bool> _enableDamageBatching;
        private ConfigEntry<float> _damageSyncInterval;
        private ConfigEntry<float> _combatSyncRadius;
        private ConfigEntry<bool> _enableSkillScaling;
        private ConfigEntry<float> _skillDamageMultiplier;
        private ConfigEntry<bool> _enableCombatLogging;

        // Core systems
        private WeaponDatabase _weaponDatabase;
        private WeaponManager _weaponManager;
        private DamageCalculator _damageCalculator;
        private CombatSyncManager _syncManager;
        private Harmony _harmony;

        // Track if Skills module is available
        private bool _skillsModuleAvailable = false;

        public void OnCoreReady()
        {
            CoreAPI.Log.LogInfo($"[{ModuleID}] Initializing Combat module...");

            // Load configuration
            LoadConfiguration();

            if (!_enableCombatSystem.Value)
            {
                CoreAPI.Log.LogInfo($"[{ModuleID}] Combat system is disabled in config.");
                return;
            }

            // Check if Skills module is available
            _skillsModuleAvailable = CoreLifecycle.IsModuleRegistered("UltimaValheim.Skills");
            if (_skillsModuleAvailable)
            {
                CoreAPI.Log.LogInfo($"[{ModuleID}] Skills module detected - skill scaling enabled");
            }

            // Initialize weapon database
            _weaponDatabase = new WeaponDatabase();
            string csvPath = GetWeaponCSVPath();
            if (!_weaponDatabase.LoadFromCSV(csvPath))
            {
                CoreAPI.Log.LogError($"[{ModuleID}] Failed to load weapon database! Combat system disabled.");
                return;
            }

            // Initialize core systems
            _weaponManager = new WeaponManager(_weaponDatabase);
            _damageCalculator = new DamageCalculator(_weaponDatabase, _skillsModuleAvailable);
            _syncManager = new CombatSyncManager(
                ModuleID,
                _damageSyncInterval.Value,
                _combatSyncRadius.Value,
                _enableDamageBatching.Value
            );

            // Register weapons with Jotunn
            _weaponManager.RegisterWeapons();

            // Setup network handlers
            RegisterNetworkHandlers();

            // Apply Harmony patches
            _harmony = new Harmony("com.valheim.ultima.combat");
            ApplyHarmonyPatches();

            CoreAPI.Log.LogInfo($"[{ModuleID}] Combat module initialized successfully!");
            CoreAPI.Log.LogInfo($"[{ModuleID}] Loaded {_weaponDatabase.WeaponCount} weapon entries");
        }

        public void OnPlayerJoin(Player player)
        {
            if (!_enableCombatSystem.Value || player == null)
                return;

            long playerID = player.GetPlayerID();
            CoreAPI.Log.LogInfo($"[{ModuleID}] Player {player.GetPlayerName()} ({playerID}) joined");

            // Initialize damage cache for player
            _damageCalculator.InitializePlayerCache(playerID);

            // Subscribe to player events if Skills module is present
            if (_skillsModuleAvailable)
            {
                SubscribeToSkillEvents(player);
            }
        }

        public void OnPlayerLeave(Player player)
        {
            if (!_enableCombatSystem.Value || player == null)
                return;

            long playerID = player.GetPlayerID();
            CoreAPI.Log.LogInfo($"[{ModuleID}] Player {player.GetPlayerName()} ({playerID}) leaving");

            // Clean up damage cache
            _damageCalculator.ClearPlayerCache(playerID);
        }

        public void OnSave()
        {
            if (!_enableCombatSystem.Value)
                return;

            // Combat module doesn't need to save data (weapons are items, damage is calculated)
            // But we can log for debugging
            if (_enableCombatLogging.Value)
            {
                CoreAPI.Log.LogDebug($"[{ModuleID}] OnSave called");
            }
        }

        public void OnShutdown()
        {
            CoreAPI.Log.LogInfo($"[{ModuleID}] Shutting down Combat module...");

            // Cleanup
            _syncManager?.Shutdown();
            _damageCalculator?.Cleanup();
            _harmony?.UnpatchSelf();

            CoreAPI.Log.LogInfo($"[{ModuleID}] Combat module shut down successfully");
        }

        #region Configuration

        private void LoadConfiguration()
        {
            var config = CoreAPI.Config;

            _enableCombatSystem = config.Bind(
                "Combat.General",
                "EnableCombatSystem",
                true,
                "Enable the Ultima Valheim combat system"
            );

            _enableDamageBatching = config.Bind(
                "Combat.Performance",
                "EnableDamageBatching",
                true,
                "Batch damage updates for better performance (recommended for PvP)"
            );

            _damageSyncInterval = config.Bind(
                "Combat.Performance",
                "DamageSyncInterval",
                0.1f,
                "Damage sync interval in seconds (lower = more responsive, higher = better performance)"
            );

            _combatSyncRadius = config.Bind(
                "Combat.Performance",
                "CombatSyncRadius",
                50f,
                "Distance to sync combat updates in meters (only players within this range receive updates)"
            );

            _enableSkillScaling = config.Bind(
                "Combat.Balance",
                "EnableSkillScaling",
                true,
                "Scale damage based on weapon skills"
            );

            _skillDamageMultiplier = config.Bind(
                "Combat.Balance",
                "SkillDamageMultiplier",
                1.0f,
                "Multiplier for skill-based damage bonus (1.0 = normal, 0.5 = half effectiveness)"
            );

            _enableCombatLogging = config.Bind(
                "Combat.Debug",
                "EnableCombatLogging",
                false,
                "Enable detailed combat logging (performance impact)"
            );
        }

        #endregion

        #region Network Handlers

        private void RegisterNetworkHandlers()
        {
            // Register RPC for damage sync
            CoreAPI.Network.RegisterRPC(ModuleID, "BatchDamageSync", OnBatchDamageSyncReceived);

            CoreAPI.Log.LogInfo($"[{ModuleID}] Network handlers registered");
        }

        private void OnBatchDamageSyncReceived(ZRpc rpc, ZPackage package)
        {
            _syncManager.ReceiveBatchDamage(package);
        }

        #endregion

        #region Harmony Patches

        private void ApplyHarmonyPatches()
        {
            try
            {
                // Patch Character.Damage for custom damage calculation
                _harmony.PatchAll(typeof(Patches.Character_Damage));
                
                // Patch Humanoid.EquipItem for cache invalidation
                _harmony.PatchAll(typeof(Patches.Humanoid_EquipItem));

                CoreAPI.Log.LogInfo($"[{ModuleID}] Harmony patches applied successfully");
            }
            catch (Exception ex)
            {
                CoreAPI.Log.LogError($"[{ModuleID}] Failed to apply Harmony patches: {ex}");
            }
        }

        #endregion

        #region Skills Integration

        private void SubscribeToSkillEvents(Player player)
        {
            // Subscribe to skill level up events to invalidate damage cache
            CoreAPI.Events.Subscribe<Player, string, int>("Skills.OnLevelUp",
                (p, skillName, level) =>
                {
                    if (p.GetPlayerID() == player.GetPlayerID() && IsCombatSkill(skillName))
                    {
                        _damageCalculator.InvalidatePlayerCache(p.GetPlayerID());
                        
                        if (_enableCombatLogging.Value)
                        {
                            CoreAPI.Log.LogDebug($"[{ModuleID}] Invalidated damage cache for {p.GetPlayerName()} due to {skillName} level up");
                        }
                    }
                });
        }

        private bool IsCombatSkill(string skillName)
        {
            return skillName switch
            {
                "Swordsmanship" => true,
                "Macing" => true,
                "Fencing" => true,
                "Archery" => true,
                "Parrying" => true,
                _ => false
            };
        }

        #endregion

        #region Helper Methods

        private string GetWeaponCSVPath()
        {
            // Try multiple locations for the CSV file
            string[] possiblePaths = new[]
            {
                Path.Combine(BepInEx.Paths.PluginPath, "UltimaValheim", "Ultima_Valheim_Weapons_Balance.csv"),
                Path.Combine(BepInEx.Paths.ConfigPath, "UltimaValheim", "Ultima_Valheim_Weapons_Balance.csv"),
                Path.Combine(BepInEx.Paths.BepInExRootPath, "config", "UltimaValheim", "Ultima_Valheim_Weapons_Balance.csv")
            };

            foreach (string path in possiblePaths)
            {
                if (File.Exists(path))
                {
                    CoreAPI.Log.LogInfo($"[{ModuleID}] Found weapon CSV at: {path}");
                    return path;
                }
            }

            // If not found, return default path and log warning
            string defaultPath = possiblePaths[0];
            CoreAPI.Log.LogWarning($"[{ModuleID}] Weapon CSV not found. Expected location: {defaultPath}");
            return defaultPath;
        }

        #endregion

        #region Public API

        /// <summary>
        /// Get the damage calculator (for other modules or systems)
        /// </summary>
        public DamageCalculator GetDamageCalculator() => _damageCalculator;

        /// <summary>
        /// Get the weapon manager (for other modules or systems)
        /// </summary>
        public WeaponManager GetWeaponManager() => _weaponManager;

        /// <summary>
        /// Get the sync manager (for other modules or systems)
        /// </summary>
        public CombatSyncManager GetSyncManager() => _syncManager;

        #endregion
    }
}
